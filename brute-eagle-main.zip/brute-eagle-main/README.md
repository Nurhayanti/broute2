								UNDER DEVOLOPENT🔧⚙
# Brute-eagle
A multiplatform bruteforce tool  to crack instagram,facebook and gmail with custom or inbuilt wordlist.

## Installation
•Termux
_______________
	$ apt update -y && apt upgrade -y
	$ pkg install git
	$ pkg install figlet
  	$ pkg install python
	$ pkg install python2
	$ git clone https://github.com/WH1T3-E4GL3/brute-eagle.git
	$ cd brute-eagle
	$ pip install mechanize
	$ pip install splinter
  	$ pip install smtplib
  	$ pip install random
  	$ pip install smtplib
  	$ pip install requests
  	$ pip install threading
  	$ pip install subprocess
	$ git pull
	$ chmod +x *
	$ pip install -r requirements.txt
	$ python brute-eagle.py
	
	# I given manual installation of some modules by pip install <module name> because sometimes it not works with the auto installation. So better to do it manually
	




## Screenshot

![Screenshot_2022-12-29_05_39_22](https://user-images.githubusercontent.com/118425907/209940420-eadadfb9-fc2d-4b08-83cb-273b9051d4c1.png)
## Author
<a href="https://github.com/WH173-E4GL3"><img title="Github" src="https://img.shields.io/badge/WH173-E4GL3-brightgreen?style=for-the-badge&logo=github"></a>
## Support
[![Instagram](https://img.shields.io/badge/TELEGRAM-red?style=for-the-badge&logo=telegram)](https://t.me/Ka_KsHi_HaTaKe)

# Warning


### ***This Tool is For Educational Purposes Only Iam Not Responsible For Your Unwanted Use***
